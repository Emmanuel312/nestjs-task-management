export interface JWtPayload {
  username: string;
}
